import setuptools

setuptools.setup(
    include_package_data = True,
    install_requires=[
          'smbus',
    ]
)
