''' This folder contains a Python script to test the 'tfmpi2c' a module for the
Benewake TFMini-Plus Lidar device operating in I2C communications mode.'''
